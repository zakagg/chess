import java.io.Serializable;

public class Annance implements Serializable {
	
    private  static  final  long serialVersionUID =  1350092881346723535L;

	public String domaine;
	public String description;
	public String prix;
	
	public Annance(String d,String des,String p) {
		domaine=d;
		description = des;
		prix =p;
	}

}
