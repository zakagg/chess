import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Multiple  extends Thread  {
	 private Socket connection;
	 private BufferedReader in;
	 private PrintWriter out;
	 private Anannce anance;
	 private Server serv;
	 private ObjectInputStream obj_in;
	 private ObjectOutputStream obj_out;
	
	
	public Multiple(Socket connection,Server serv)
	{
		 try{
		 this.connection=connection;
		 InputStream in=connection.getInputStream();
		 OutputStream out=connection.getOutputStream();
		 this.in = new BufferedReader(new InputStreamReader(in));
		 this.out = new PrintWriter(new OutputStreamWriter(out));
		 
		 this.serv=serv;
		 } catch (IOException ex) {
		 System.err.println(ex);
		 }
		 }
		 public void run() {
			
	        	try {
	        			out.write("donner votre User_name. \n");
						out.flush();
						String id=in.readLine();
						boolean exist= serv.exist_id(id);
						String port=connection.getPort()+"";
						String ip= connection.getInetAddress()+"";
//						out.write("si vous voulez ajjouter anonce taper  1. \n");
//						out.write(" voir  les anonce taper  2. \n");
//						out.write("si vous voulez quiter taper 3. \n");
//						out.write("si vous voulez envoyer un message taper 4. \n");
//						out.write("si vous voulez supprimer une annance un message taper 5. \n");
//						out.write("si vous voulez afficher la liste des message locale 6 \n");
//						out.write("Vous voulez supprimer un messages appuyer sur 7  \n");
//						out.write("Vous voulez stocker les message dans le serveur messages appuyer sur 8  \n");
//						out.flush();
						while(true)
						{
						String ce_que_fais=in.readLine();
						System.out.println(ce_que_fais);
						if(ce_que_fais.equals("1"))
						{
						out.write("donner le domaine de l'annonce. \n");
						out.flush();
						String domaine=in.readLine();
						out.write("donner le prix \n");
						out.flush();
						String prix=in.readLine();
						out.write("donner le descrptif \n");
						out.flush();
						String descriptif=in.readLine();
						out.flush();
						obj_in=new ObjectInputStream(connection.getInputStream()) ;
						Annance a =(Annance) obj_in.readObject();
						System.out.println("imed "+a.domaine+" "+a.description+" "+a.prix);
						Anannce anance=new Anannce(id,domaine,prix,descriptif,ip,port);
						System.out.println("1 ici  "+ id +"   " +domaine+"    "+prix+ "    "+descriptif);
						System.out.println("la chaine est    "+anance.get_domaine_Anannce());
						if(serv.l.size()==0)
						anance.set_referance(0);
						else
						anance.set_referance(Integer.parseInt(serv.l.get(serv.l.size()-1).get_referance())+1);
						serv.addListe(anance);
						serv.affiche_list();
						}
						if(ce_que_fais.equals("2"))
						{
							out.write("Si Vous voulez voir tout les element de liste appuyer sur 1 \n");
							out.write("Si Vous voulez Voir selon le domain apuyer sur2 \n");
							out.flush();
							String afficher=in.readLine();
							if(afficher.equals("1"))
							{
								System.out.println("je passe ");
								obj_out=new ObjectOutputStream(connection.getOutputStream());
								obj_out.writeObject(serv.list_annance_to_list_string());
								obj_out.flush();
							}
							if(afficher.equals("2"))
							{
								out.write("Donner le dommain \n");
								out.flush();
								String domaine=in.readLine();
								obj_out=new ObjectOutputStream(connection.getOutputStream());
								obj_out.writeObject(serv.list_annance_domain_to_list_string(domaine));
								obj_out.flush();
							}
						}
						
						if(ce_que_fais.equals("4")) 
						{
							out.write("Donner le id du user \n");
							out.flush();
							String id_user_msg=in.readLine();
							System.out.println("j' envois a letulisateur   "+id_user_msg);
							out.write("ecriver le message que vous voullez envoyer \n");
							out.flush();
							String msg=in.readLine();
							System.out.println(msg);
							msg=msg+ " from  ///"+id;
							Message message_enre=null;
							if(serv.liste_msg.size()==0)
								message_enre=new Message(id,msg,0+"",id_user_msg);
							else {
								message_enre=new Message(id,msg,serv.liste_msg.get(serv.liste_msg.size()-1)+"",id_user_msg);
							}
							
							
							serv.liste_msg.add(message_enre);
							String ip_port=serv.search_ip_user(id_user_msg).substring(1);
							System.out.println("l @ et port "+ (ip_port));
														
							String[] parts = ip_port.split(" ");
							byte[] receiveData = new byte[1024];
							DatagramSocket clientSocket = new DatagramSocket();
							InetAddress IPAddress = InetAddress.getByName(parts[0]);
							byte[] sendData = new byte[1024];
							sendData = msg.getBytes();
							DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 8888);
							clientSocket.send(sendPacket);
							//DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
							//clientSocket.receive(receivePacket);
							//String sentence1 = new String( receivePacket.getData(),0, receivePacket.getLength());
							//System.out.println(sentence1);
							
						}
						if(ce_que_fais.equals("5"))//vous voulez suprimer
						{
							obj_out=new ObjectOutputStream(connection.getOutputStream());
							obj_out.writeObject(serv.list_annance_to_list_string());
							obj_out.flush();
							out.write("donner une valeur de ref pour supprimer \n");
							out.flush();
							String ref=in.readLine();
							int a=Integer.parseInt(ref);
							serv.delliste(a);
							obj_out=new ObjectOutputStream(connection.getOutputStream());
							obj_out.writeObject(serv.list_annance_to_list_string());
							obj_out.flush();
							
						}
						if(ce_que_fais.equals("6"))//vous voulez voir votre liste de msg
						{
							out.write("Voici la liste des messages locale \n");
							out.flush();
						}
						if(ce_que_fais.equals("7"))
						{
							out.write("Vous voulez supprimer quelle messages entrer Svp la referanace \n");
							out.flush();
							out.write("Voici la liste des messages du serveur \n");
							out.flush();
							obj_out=new ObjectOutputStream(connection.getOutputStream());
							List<Message> liste_msg=new ArrayList<>();
							for(int i=0;i<serv.liste_msg.size();i++)
							{
								System.out.println("la vale rst"+ id+   "hhhhh"+serv.liste_msg.get(i).get_id()+"hhhh");
								if(serv.liste_msg.get(i).get_id().equals(id))
									{
										liste_msg.add(serv.liste_msg.get(i));		
									}
							}
							List<String> resultat=new ArrayList<String>();
							for (int i=0;i<liste_msg.size();i++)
							{
								resultat.add(liste_msg.get(i).tostring());
							}
							obj_out.writeObject(resultat);
							obj_out.flush();
							String ref_del=in.readLine();
							for(int i=0;i<serv.liste_msg.size();i++)
							{
								if(serv.liste_msg.get(i).get_ref().equals(ref_del))
									{
										serv.liste_msg.remove(i);
									}
							}
							
							
							
						}
						if(ce_que_fais.equals("8"))
						{
							out.write("Voici la liste des messages du serveur \n");
							out.flush();
							obj_out=new ObjectOutputStream(connection.getOutputStream());
							List<Message> liste_msg=new ArrayList<>();
							for(int i=0;i<serv.liste_msg.size();i++)
							{
								System.out.println("la vale rst"+ id+   "hhhhh"+serv.liste_msg.get(i).get_id()+"hhhh");
								if(serv.liste_msg.get(i).get_id().equals(id))
									{
										liste_msg.add(serv.liste_msg.get(i));		
									}
							}
							List<String> resultat=new ArrayList<String>();
							for (int i=0;i<liste_msg.size();i++)
							{
								resultat.add(liste_msg.get(i).tostring());
							}
							obj_out.writeObject(resultat);
							obj_out.flush();
							
							List<Message> liste_msg1=new ArrayList<>();
							for(int i=0;i<serv.liste_msg.size();i++)
							{
								System.out.println("la vale rst"+ id+   "hhhhh"+serv.liste_msg.get(i).get_id_user_msg()+"hhhh");
								if(serv.liste_msg.get(i).get_id_user_msg().equals(id))
									{
										liste_msg1.add(serv.liste_msg.get(i));									
									}
							}
							List<String> resultat1=new ArrayList<String>();
							for (int i=0;i<liste_msg1.size();i++)
							{
								resultat1.add(liste_msg1.get(i).tostring());
							}
							
							obj_out.writeObject(resultat1);
							obj_out.flush();
							
						}
				 }}
	        	catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println("it's me imed");
					e.printStackTrace();
				}
	            try {
					out.flush();
					sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            try {
					connection.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
	            try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}		 
		 }
