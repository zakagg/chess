import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
	 	public static  List<Message> liste_msg=new ArrayList<>();
		public List<Anannce> l = new ArrayList<>();
		public List<Anannce> getListe()
		{
			return this.l;
		}
		
		public List<String> list_message_to_list_string()
		{
			List<String> resultat=new ArrayList<String>();
			for (int i=0;i<this.liste_msg.size();i++)
			{
				resultat.add(this.liste_msg.get(i).tostring());
			}
			return resultat;
		}
		public  synchronized void addListe(Anannce annonce)
		{
			this.l.add(annonce);
		}
		public  synchronized void delliste(int ref)
		{
			for (int i=0;i<l.size();i++)
			{
				if(Integer.parseInt(l.get(i).get_referance())==ref)
				{
					l.remove(i);
				}
			}
		}
		public void affiche_list()
		{
			for(int i=0;i<this.l.size();i++)
			{
				System.out.println(this.l.get(i).tostring());
			}
		}
		public boolean exist_id(String id)
		{
			for(int i=0;i<this.l.size();i++)
			{
				if (this.l.get(i).get_id_Anannce()==id)
				{
					return true;
				}
			}
			return false;
		}
		
		public List<String> list_annance_to_list_string()
		{
			List<String> resultat=new ArrayList<String>();
			for (int i=0;i<this.l.size();i++)
			{
				resultat.add(this.l.get(i).tostring());
			}
			return resultat;
		}
		
		
		public String search_ip_user(String id_user)
		{
			for (int i=0;i<this.l.size();i++)
			{
				if(this.l.get(i).get_id_Anannce().equals(id_user))
					{
					
					return this.l.get(i).get_ip()+ " "+this.l.get(i).get_port(); 
					}
				
			}
			
			return null;
		}
		
		public List<String> list_annance_domain_to_list_string(String domain)
		{
			List<String> resultat=new ArrayList<String>();
			for (int i=0;i<this.l.size();i++)
			{
				if(this.l.get(i).get_domaine_Anannce().equals(domain))
					{
						resultat.add(this.l.get(i).tostring());
					}
			}
			return resultat;
		}		
		
		static int x=0;
		public static void main(String[] args) throws IOException, InterruptedException {
	        ServerSocket server = new ServerSocket(2001);
	        Server serv=new Server();
	        while(true)
	        {
	            Socket connection = server.accept();    
	            Multiple mult=new Multiple(connection,serv);
	            mult.start();

	        }
	}
}
