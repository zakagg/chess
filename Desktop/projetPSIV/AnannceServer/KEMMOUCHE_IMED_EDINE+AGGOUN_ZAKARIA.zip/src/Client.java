import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Client extends Thread {	
	private static List<Message> list_msg=new ArrayList<>();
	public List<Message> get_list ()
	{
		return this.list_msg;
	}
	
	public List<String> list_msg_to_list_string()
	{
		List<String> resultat=new ArrayList<String>();
		for (int i=0;i<this.list_msg.size();i++)
		{
			resultat.add(this.list_msg.get(i).tostring());
		}
		return resultat;
	}
	
	public void delete_msg(int i)
	{
		
			list_msg.remove(i);
	}	
	
	public static void affiche_list(List<String> l)
	{
		for(int i=0;i<l.size();i++)
		{
			System.out.println(l.get(i));
		}
	}
	
	public void run() 
	{
	    PrintWriter out = null;
        BufferedReader networkIn = null;
        ObjectInputStream obj_in;
   	 	ObjectOutputStream obj_out;
   	 	
        try {
            Socket theSocket = new Socket("localhost", 2001);
            System.out.println("Client: Connect� au serveur d'echo "+ theSocket);
            networkIn = new BufferedReader( new InputStreamReader(theSocket.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter (theSocket.getOutputStream()));
           // obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
   		 	//obj_out=new ObjectOutputStream(theSocket.getOutputStream());   		 
            Scanner myObj = new Scanner(System.in);  // Create a Scanner object
            	System.out.println(networkIn.readLine());
            	String id = myObj.nextLine();
            	out.write(id+"\n");
            	out.flush();
            	while(true)
           	 	{
            	System.out.println("si vous voulez ajjouter anonce taper  1. \n");
                System.out.println(" voir  les anonce taper  2. \n");
                System.out.println("si vous voulez quiter taper 3. \n");
                System.out.println("si vous voulez envoyer un message taper 4. \n");
                System.out.println("si vous voulez supprimer une annance un message taper 5. \n");
                System.out.println("si vous voulez afficher la liste des message locale 6 \n");
                System.out.println("Vous voulez supprimer un messages appuyer sur 7  \n");
                System.out.println("Vous voulez stocker les message dans le serveur messages appuyer sur 8  \n");
                String ce_que_fais = myObj.nextLine();//  je choisis 1 ou 2 ou 3
            	out.write(ce_que_fais+"\n");
            	out.flush();
            	
                
                if(ce_que_fais.equals("1"))//ajjouter une annonce
                {
            	System.out.println(networkIn.readLine());
            	String domaine = myObj.nextLine();
            	out.write(domaine+"\n");
            	out.flush();
            	System.out.println(networkIn.readLine());
            	String prix = myObj.nextLine();
            	out.write(prix+"\n");
            	out.flush();
            	//ici l ajjout
            	System.out.println(networkIn.readLine());
            	String descriptif = myObj.nextLine();
            	out.write(descriptif+"\n");
            	out.flush();
            	obj_out=new ObjectOutputStream(theSocket.getOutputStream()) ;
            	Annance a = new Annance(domaine,descriptif,prix);
            	obj_out.writeObject(a);
            	System.out.println("je suis dans le 1");            	
                }
                if(ce_que_fais.equals("2"))
                {
                	System.out.println(networkIn.readLine());
                	System.out.println(networkIn.readLine());
                	String afficher = myObj.nextLine();
                	out.write(afficher+"\n");
                	out.flush();
                	if(afficher.equals("1"))
                	{
                		obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
                		List<String> resultat=	(List<String>) obj_in.readObject();
                		affiche_list(resultat);	
                	}
                	if(afficher.equals("2"))
                	{
                		System.out.println(networkIn.readLine());
                		String domaine = myObj.nextLine();
                		out.write(domaine+"\n");
                    	out.flush();
                    	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
                		List<String> resultat=	(List<String>) obj_in.readObject();
                		affiche_list(resultat);
                	}
                	
                }
                if(ce_que_fais.equals("3"))
                {
                	break;
                }
                if(ce_que_fais.equals("4"))
                {
                	System.out.println(networkIn.readLine());
                	String id_user_msg = myObj.nextLine();
                	out.write(id_user_msg+"\n");
                	out.flush();
                	
                	System.out.println(networkIn.readLine());
                	String msg = myObj.nextLine();
                	out.write(msg+"\n");
                	out.flush();	                	
                }   
                if(ce_que_fais.equals("5"))//vous voulez suprimer
				{
                	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
            		List<String> resultat=	(List<String>) obj_in.readObject();
            		affiche_list(resultat);
            		System.out.println(networkIn.readLine());
            		String ref = myObj.nextLine();
            		out.write(ref+"\n");
                	out.flush();
                	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
            		 resultat=	(List<String>) obj_in.readObject();
            		affiche_list(resultat);
            		
				}
                if(ce_que_fais.equals("6"))
                {
                	System.out.println(networkIn.readLine());
                	for(int i=0;i<list_msg.size();i++)
                	{
                		System.out.println(list_msg.get(i).tostring());
                	}
                }
                if(ce_que_fais.equals("7"))
                {
                	System.out.println(networkIn.readLine());
                	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
            		List<String> resultat=	(List<String>) obj_in.readObject();
            		System.out.println(resultat);
            		String ref_msg_del = myObj.nextLine();
            		out.write(ref_msg_del+"\n");
                	out.flush();
            		
            	//	
                	
                }
                if(ce_que_fais.equals("8"))
                {
                	System.out.println(networkIn.readLine());
                	System.out.println("list des msgs envoyer");
                	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
                	
            		List<String> resultat=	(List<String>) obj_in.readObject();
            		System.out.println("vous avez envoyer");
            		System.out.println(resultat);
            	//	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
                	
            		List<String> resultat1=	(List<String>) obj_in.readObject();
            		System.out.println("recus");
            		System.out.println(resultat1);
            		
            	
					 
                }                
        }}
        catch (IOException | ClassNotFoundException ex) {System.err.println(ex);
        } finally {
            try {
                if (networkIn != null) networkIn.close();
                if (out != null) out.close();
            } catch (IOException ex) {}
        }
        
   	 	}		
	
    public static void main(String[] args) throws ClassNotFoundException
    {
    	Client client=new Client();
    	client.start();
    	WaitMessage wait=new WaitMessage(client);
    	wait.start();
    }
    }
