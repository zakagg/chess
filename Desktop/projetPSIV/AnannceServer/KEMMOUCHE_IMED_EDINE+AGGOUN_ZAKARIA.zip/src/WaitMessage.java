import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

public class WaitMessage extends Thread {
 static int port=8888;
 Client c;
 public WaitMessage(Client c) {
	 this.c=c;
}
	public  void run() 
	{
		DatagramSocket serverSocket=null;
		
		try {
			
			serverSocket = new DatagramSocket(8888);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] receiveData = new byte[1024];
		
		while (true)
	{
		DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
		try {
			serverSocket.receive(receivePacket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sentence = new String( receivePacket.getData(),0, receivePacket.getLength());		
		System.out.println("jai recus    "+ sentence);
		String[] parts = sentence.split(" from  ///");
		String id=parts[parts.length-1];
		System.out.println(id);
		String message="";
		for(int i=0;i<parts.length-1;i++)
		{
			message=message+parts[i];
		}
		int dernier=0;
		if(c.get_list().size()==0)
		{
			Message msg=new Message(id,message,"0");
			c.get_list().add(msg);
		}
		else
		{
			String den_str=c.get_list().get(c.get_list().size()-1)+"";
			Message msg=new Message(id,message,den_str);
			c.get_list().add(msg);
		}
		
	}
	
}
	}