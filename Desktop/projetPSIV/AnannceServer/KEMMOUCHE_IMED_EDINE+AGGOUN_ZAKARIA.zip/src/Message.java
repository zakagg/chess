public class Message 
{
	private String id;
	private String msg;
	private String ref;
	private String id_user_msg;
	public Message (String id,String msg,String ref,String id_user_msg)
	
	{
		this.id=id;
		this.msg=msg;
		this.ref=ref;
		this.id_user_msg=id_user_msg;
	}
	
public Message (String id,String msg,String ref)
	
	{
		this.id=id;
		this.msg=msg;
		this.ref=ref;
		
	}
	
	
	public String get_ref()
	{
		return this.ref;
	}
	
	public String get_id()
	{
		return this.id;
	}
	
	public String tostring()
	{
		return "ref "+ref  +" id "+id+" a envoyer "+ "  msg "+msg;
	}
	public String get_id_user_msg()
	{
		return this.id_user_msg;
	}	
	
}
