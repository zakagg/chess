public class Anannce {
	private String id;
	private String domaine;
	private String prix;
	private String descriptif;
	private String ip;
	private String port;
	private int referance;
	
	
	public Anannce(String id,String domaine,String prix,String descriptif,String ip,String port)
	{
		this.id=id;
		this.prix=prix;
		this.domaine=domaine;
		this.descriptif=descriptif;
		this.ip=ip;
		this.port=port;
	}
	public int set_referance (int a)
	{
		return referance=a;
	}
	public String get_referance()
	{
		return referance+"";
	}
	
	public void set_Anannce(String id,String domaine,String prix,String descriptif,String ip,String port)
	{
		this.prix=id;
		this.prix=prix;
		this.domaine=domaine;
		this.descriptif=descriptif;
		this.ip=ip;
		this.port=port;
	}
	
	public String get_id_Anannce()
	{
		return this.id;
	}
	
	public String get_domaine_Anannce()
	{
		return this.domaine;
	}
	public String get_prix_Anannce()
	{
		return this.prix;
	} 
	
	public String get_descriptif()
	{
		return this.descriptif;
	}
	
	public String get_ip()
	{
		return this.ip;
	}
	
	public String get_port()
	{
		return this.port;
	}
	
	public String tostring()
	{
		return "ref "+referance+ " id "+ this.id+ "  "+ "prix "+ this.prix+ "  "+ "domaine " +this.domaine+"  "+"descriptif "+this.descriptif;
	}	
}

/*
 * import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

public class Client {
	
	public static void affiche_list(List<String> l)
	{
		for(int i=0;i<l.size();i++)
		{
			System.out.println(l.get(i));
		}
	}
    
    public static void main(String[] args) throws ClassNotFoundException
    {
        PrintWriter out = null;
        BufferedReader networkIn = null;
        ObjectInputStream obj_in;
   	 	ObjectOutputStream obj_out;
        try {
            Socket theSocket = new Socket("localhost", 200);
            System.out.println("Client: Connect� au serveur d'echo "+ theSocket);
            networkIn = new BufferedReader( new InputStreamReader(theSocket.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter (theSocket.getOutputStream()));
           // obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
   		 	//obj_out=new ObjectOutputStream(theSocket.getOutputStream());
   		 
            Scanner myObj = new Scanner(System.in);  // Create a Scanner object
            
            
            
            
            	System.out.println(networkIn.readLine());
            	String id = myObj.nextLine();
            	out.write(id+"\n");
            	out.flush();
            	
            	
            	System.out.println(networkIn.readLine());
                System.out.println(networkIn.readLine());
                System.out.println(networkIn.readLine());
                System.out.println(networkIn.readLine());
                
            	
                String ce_que_fais = myObj.nextLine();//  je choisis 1 ou 2 ou 3
            	out.write(ce_que_fais+"\n");
            	out.flush();
            	
                
                if(ce_que_fais.equals("1"))//ajjouter une annonce
                {
            	System.out.println(networkIn.readLine());
            	String domaine = myObj.nextLine();
            	out.write(domaine+"\n");
            	out.flush();
            	System.out.println(networkIn.readLine());
            	String prix = myObj.nextLine();
            	out.write(prix+"\n");
            	out.flush();
            	//ici l ajjout
            	System.out.println(networkIn.readLine());
            	String descriptif = myObj.nextLine();
            	out.write(descriptif+"\n");
            	out.flush();
            	System.out.println("je suis dans le 1");            	
                }
                if(ce_que_fais.equals("2"))
                {
                	System.out.println(networkIn.readLine());
                	System.out.println(networkIn.readLine());
                	String afficher = myObj.nextLine();
                	out.write(afficher+"\n");
                	out.flush();
                	if(afficher.equals("1"))
                	{
                		obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
                		List<String> resultat=	(List<String>) obj_in.readObject();
                		affiche_list(resultat);	
                	}
                	if(afficher.equals("2"))
                	{
                		System.out.println(networkIn.readLine());
                		String domaine = myObj.nextLine();
                		out.write(domaine+"\n");
                    	out.flush();
                    	obj_in=new ObjectInputStream(theSocket.getInputStream()) ;
                		List<String> resultat=	(List<String>) obj_in.readObject();
                		affiche_list(resultat);
                	}
                	
                }
                if(ce_que_fais.equals("4"))
                {
                	System.out.println(networkIn.readLine());
                	String id_user_msg = myObj.nextLine();
                	out.write(id_user_msg+"\n");
                	out.flush();
                	System.out.println(networkIn.readLine());
                	String msg = myObj.nextLine();
                	out.write(msg+"\n");
                	out.flush();
                	                	
                }
                
        }
        catch (IOException ex) {System.err.println(ex);
        } finally {
            try {
                if (networkIn != null) networkIn.close();
                if (out != null) out.close();
            } catch (IOException ex) {}
        }
    }
    
    }

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Multiple  extends Thread  {
	 private Socket connection;
	 private BufferedReader in;
	 private PrintWriter out;
	 private Anannce anance;
	 private Server serv;
	 private ObjectInputStream obj_in;
	 private ObjectOutputStream obj_out;
	
	public Multiple(Socket connection,Server serv)
	{
		 try{
		 this.connection=connection;
		 InputStream in=connection.getInputStream();
		 OutputStream out=connection.getOutputStream();
		 this.in = new BufferedReader(new InputStreamReader(in));
		 this.out = new PrintWriter(new OutputStreamWriter(out));
		 
		 
		 
		 this.serv=serv;
		 } catch (IOException ex) {
		 System.err.println(ex);
		 }
		 }
		 public void run() {
			
	        	try {
					
					
						out.write("donner votre User_name. \n");
						out.flush();
						String id=in.readLine();
						
						boolean exist= serv.exist_id(id);
						String port=connection.getPort()+"";
						String ip= connection.getInetAddress()+"";
						out.write("si vous voulez ajjouter anonce taper  1. \n");
						out.write(" voir  les anonce taper  2. \n");
						out.write("si vous voulez quiter taper 3. \n");
						out.write("si vous voulez envoyer un message taper 4. \n");
						out.flush();
						String ce_que_fais=in.readLine();
						System.out.println(ce_que_fais);
						if(ce_que_fais.equals("1"))
						{
						out.write("donner le domaine de l'annonce. \n");
						out.flush();
						String domaine=in.readLine();
						out.write("donner le prix \n");
						out.flush();
						String prix=in.readLine();
						out.write("donner le descrptif \n");
						out.flush();
						String descriptif=in.readLine();
						out.flush();
						Anannce anance=new Anannce(id,domaine,prix,descriptif,ip,port);
						System.out.println("1 ici  "+ id +"   " +domaine+"    "+prix+ "    "+descriptif);
						System.out.println("la chaine est    "+anance.get_domaine_Anannce());
						serv.addListe(anance);
						serv.affiche_list();
						}
						if(ce_que_fais.equals("2"))
						{
							out.write("Vous voulez voir tout les element de liste \n");
							out.write("Vous voulez Voir selon le domain \n");
							out.flush();
							String afficher=in.readLine();
							if(afficher.equals("1"))
							{
								System.out.println("je passe ");
								obj_out=new ObjectOutputStream(connection.getOutputStream());
								obj_out.writeObject(serv.list_annance_to_list_string());
								obj_out.flush();
							}
							if(afficher.equals("2"))
							{
								out.write("Donner le dommain \n");
								out.flush();
								String domaine=in.readLine();
								obj_out=new ObjectOutputStream(connection.getOutputStream());
								obj_out.writeObject(serv.list_annance_domain_to_list_string(domaine));
								obj_out.flush();
							}
						}
						
						if(ce_que_fais.equals("4")) 
						{
							out.write("Donner le id du user \n");
							out.flush();
							String id_user_msg=in.readLine();
							System.out.println("j' envois a letulisateur   "+id_user_msg);
							
							
							out.write("ecriver le message que vous voullez envoyer \n");
							out.flush();
							String msg=in.readLine();
							System.out.println(msg);
							String ip_port=serv.search_ip_user(id_user_msg).substring(1);
							System.out.println("l @ et port "+ (ip_port));
							
							
						}
				 }
	        	catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            try {
					out.flush();
					sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            try {
					connection.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
	            try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}		 
		 }
		 
		 
		 
		 
		 import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
		public List<Anannce> l = new ArrayList<>();
		public List<Anannce> getListe()
		{
			return this.l;
		}
		public  synchronized void addListe(Anannce annonce)
		{
			this.l.add(annonce);
		}
		public void affiche_list()
		{
			for(int i=0;i<this.l.size();i++)
			{
				System.out.println(this.l.get(i).tostring());
			}
		}
		public boolean exist_id(String id)
		{
			for(int i=0;i<this.l.size();i++)
			{
				if (this.l.get(i).get_id_Anannce()==id)
				{
					return true;
				}
			}
			return false;
		}
		
		public List<String> list_annance_to_list_string()
		{
			List<String> resultat=new ArrayList<String>();
			for (int i=0;i<this.l.size();i++)
			{
				resultat.add(this.l.get(i).tostring());
			}
			return resultat;
		}
		
		
		public String search_ip_user(String id_user)
		{
			for (int i=0;i<this.l.size();i++)
			{
				if(this.l.get(i).get_id_Anannce().equals(id_user))
					{
					
					return this.l.get(i).get_ip()+ " "+this.l.get(i).get_port(); 
					}
				
			}
			
			return null;
		}
		
		
		public List<String> list_annance_domain_to_list_string(String domain)
		{
			List<String> resultat=new ArrayList<String>();
			for (int i=0;i<this.l.size();i++)
			{
				if(this.l.get(i).get_domaine_Anannce().equals(domain))
					{
						resultat.add(this.l.get(i).tostring());
					}
			}
			return resultat;
		}
		
		
		static int x=0;
		public static void main(String[] args) throws IOException, InterruptedException {
	        ServerSocket server = new ServerSocket(2000);
	        Server serv=new Server();
	        while(true)
	        {
	            Socket connection = server.accept();    
	            Multiple mult=new Multiple(connection,serv);
	            mult.start();

	        }
	}
}

		 
		 
		 







*/
